package com.kardusinfo.footballmatchinfo.Interface

import com.kardusinfo.footballmatchinfo.Specials.Team

interface InfoView {
    fun showTeamEmblem(team: Team?)
}